﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace exam
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void DisplayProducts()
        {
            string connectionString = "Your_Connection_String"; // Замените на свою строку подключения к базе данных
            string query = "SELECT ProductName, ProductDescription, ProductCost, ProductDiscountAmount FROM Product";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                DataTable dt = new DataTable();
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                    productsDataGridView.DataSource = dt; // productsDataGridView - название вашего DataGridView
                }
            }
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            string searchString = searchTextBox.Text;
            (productsDataGridView.DataSource as DataTable).DefaultView.RowFilter = $"ProductName LIKE '%{searchString}%'";
        }

        private void SortByPriceButton_Click(object sender, EventArgs e)
        {
            DataView dv = (productsDataGridView.DataSource as DataTable).DefaultView;
            if (dv.Sort == "ProductCost ASC")
            {
                dv.Sort = "ProductCost DESC";
            }
            else
            {
                dv.Sort = "ProductCost ASC";
            }
        }

        private void DiscountComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRange = discountComboBox.SelectedItem.ToString();
            DataView dv = (productsDataGridView.DataSource as DataTable).DefaultView;

            switch (selectedRange)
            {
                case "0-9,99%":
                    dv.RowFilter = "ProductDiscountAmount >= 0 AND ProductDiscountAmount < 10";
                    break;
                case "10-14,99%":
                    dv.RowFilter = "ProductDiscountAmount >= 10 AND ProductDiscountAmount < 15";
                    break;
                case "15% и более":
                    dv.RowFilter = "ProductDiscountAmount >= 15";
                    break;
                default:
                    dv.RowFilter = string.Empty;
                    break;
            }
        }

    }
}
