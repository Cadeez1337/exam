﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exam
{
    public partial class LoginForm : Form
    {
        private int loginAttempts = 0;
        private string actualCaptcha;

        public LoginForm()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        private void GenerateCaptcha()
        {
            Random random = new Random();
            actualCaptcha = "";
            for (int i = 0; i < 5; i++)
            {
                int value = random.Next(65, 90); // Генерация случайного символа (A-Z)
                actualCaptcha += (char)value;
            }
            captchaLabel.Text = actualCaptcha;
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;
            bool isCaptchaValid = ValidateCaptcha(captchaTextBox.Text);

            if (loginAttempts < 3 && isCaptchaValid && AuthenticateUser(username, password))
            {
                // Успешная авторизация
                OpenMainForm(username);
            }
            else if (loginAttempts >= 3)
            {
                // Блокировка входа на 10 секунд после трех неудачных попыток
                MessageBox.Show("Превышено количество попыток входа. Попробуйте позже.");
                loginAttempts = 0; // Сброс попыток после блокировки
                Task.Delay(10000).ContinueWith(_ => { });
            }
            else
            {
                // Неуспешная авторизация
                MessageBox.Show("Неудачная попытка входа.");
                loginAttempts++;
                GenerateCaptcha(); // Генерация новой CAPTCHA при неудачной попытке
            }
        }

        private bool ValidateCaptcha(string userInput)
        {
            return userInput.Equals(actualCaptcha, StringComparison.OrdinalIgnoreCase);
        }

        private bool AuthenticateUser(string username, string password)
        {
            string connectionString = "Server=ADCLG1;Database=Trade;Integrated Security=SSPI;";
            string query = "SELECT COUNT(*) FROM [User] WHERE Login = @username AND Password = @password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                connection.Open();
                int count = Convert.ToInt32(command.ExecuteScalar());
                return count > 0;
            }
        }

        private void OpenMainForm(string username)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.FormClosed += (s, args) => this.Close();
            mainForm.Show();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
}